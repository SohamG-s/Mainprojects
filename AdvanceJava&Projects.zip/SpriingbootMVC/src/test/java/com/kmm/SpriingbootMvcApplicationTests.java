package com.kmm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpriingbootMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
